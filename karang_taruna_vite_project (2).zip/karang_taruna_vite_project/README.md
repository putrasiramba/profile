# Karang Taruna Dusun — Vite React Dashboard (Minimal)

This repository is a minimal starter of the Karang Taruna Dusun dashboard created for quick local development and deployment.
It includes:
- Vite + React skeleton
- Tailwind CSS (configure & build required)
- Simple admin login using IndexedDB (default credentials: `admin` / `admin123`)
- A single-file HTML demo included in the release

## Run locally (development)

1. Install dependencies:
```bash
npm install
```

2. Start dev server:
```bash
npm run dev
```

Open `http://localhost:5173`.

## Build for production
```bash
npm run build
npm run preview
```

## Deploy to GitHub Pages
1. Build the app: `npm run build`.
2. Push the `dist/` folder contents to `gh-pages` branch, or use `gh-pages` action.
3. In repo settings -> Pages, select `gh-pages` branch (or `gh-pages` / `docs` folder) as source.

(You can also use `npm run build` and simply upload `dist/` contents to any static host.)

## Deploy to Netlify
1. Connect your GitHub repo to Netlify.
2. Set build command: `npm run build` and publish directory: `dist`.
3. Deploy — Netlify will host it automatically.

## Admin login & credentials
Default admin credential is stored on the user's browser IndexedDB (key: `admin_cred`):
- username: `admin`
- password: `admin123`

After first login, please change credential by editing IndexedDB through devtools or by adding a small UI.

## Single-file demo
There is also a single-file demo HTML included: `karang_taruna_dashboard_singlefile.html` — quick to open in any browser without build.

