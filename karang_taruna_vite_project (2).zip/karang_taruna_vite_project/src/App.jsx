import React, { useEffect, useState } from 'react'
import DashboardShell from './components/DashboardShell'
import AdminLogin from './components/AdminLogin'
import { idbGet, idbPut } from './utils/idb'

export default function App() {
  const [logged, setLogged] = useState(false);
  const [initializing, setInitializing] = useState(true);

  useEffect(()=>{
    async function init() {
      // ensure admin credential exists in IndexedDB (default: admin / admin123)
      const cred = await idbGet('admin_cred');
      if (!cred) {
        await idbPut('admin_cred', { username: 'admin', password: 'admin123' });
      }
      const session = localStorage.getItem('kt_session');
      setLogged(!!session);
      setInitializing(false);
    }
    init();
  },[]);

  if (initializing) return <div className="p-6">Memuat...</div>;

  return logged ? <DashboardShell onLogout={() => { localStorage.removeItem('kt_session'); setLogged(false); }} /> : <AdminLogin onSuccess={() => { localStorage.setItem('kt_session','ok'); setLogged(true); }} />
}
