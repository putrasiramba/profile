import React from 'react'
export default function Gallery(){return <div className="p-4 bg-white rounded-xl shadow">Halaman Galeri (mini).</div>}