import React from 'react'
export default function Profile(){return <div className="p-4 bg-white rounded-xl shadow">Halaman Profil (mini). Edit di versi lengkap.</div>}