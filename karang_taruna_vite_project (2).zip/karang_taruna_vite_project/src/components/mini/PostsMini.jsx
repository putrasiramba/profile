import React from 'react'
export default function Posts(){return <div className="p-4 bg-white rounded-xl shadow">Halaman Informasi (mini).</div>}