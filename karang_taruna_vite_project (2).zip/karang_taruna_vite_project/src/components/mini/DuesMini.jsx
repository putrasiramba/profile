import React from 'react'
export default function Dues(){return <div className="p-4 bg-white rounded-xl shadow">Halaman Iuran (mini).</div>}