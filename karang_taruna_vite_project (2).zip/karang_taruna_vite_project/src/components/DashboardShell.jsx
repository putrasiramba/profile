import React, { useState } from 'react'
// We'll embed a simplified version of the dashboard UI here for demo purposes
import Profile from './mini/ProfileMini'
import Structure from './mini/StructureMini'
import Posts from './mini/PostsMini'
import Events from './mini/EventsMini'
import Dues from './mini/DuesMini'
import Gallery from './mini/GalleryMini'

const NAV = [{ key:'dashboard', label:'Beranda' },{ key:'profile', label:'Profil' },{ key:'structure', label:'Struktur' },{ key:'posts', label:'Informasi' },{ key:'events', label:'Kegiatan' },{ key:'dues', label:'Iuran' },{ key:'gallery', label:'Galeri' }];

export default function DashboardShell({ onLogout }) {
  const [active, setActive] = useState('dashboard');
  return <div className="min-h-screen p-6 bg-neutral-50 dark:bg-neutral-900">
    <header className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-3"><div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold">KT</div><div><h1 className="text-xl font-semibold">Karang Taruna Dusun</h1><div className="text-sm text-neutral-500">Panel Admin</div></div></div>
      <div className="flex gap-2"><button className="px-3 py-2 rounded-xl border" onClick={onLogout}>Logout</button></div>
    </header>
    <nav className="mb-4"><div className="flex gap-2 overflow-auto">{NAV.map(n=>(<button key={n.key} onClick={()=>setActive(n.key)} className={\`px-3 py-2 rounded-xl \${active===n.key?'bg-blue-600 text-white':''}\`}>{n.label}</button>))}</div></nav>
    <main>{active==='dashboard' && <div className="p-6 bg-white rounded-2xl shadow">Selamat datang di Dashboard Admin.</div>}{active==='profile' && <Profile />}{active==='structure' && <Structure />}{active==='posts' && <Posts />}{active==='events' && <Events />}{active==='dues' && <Dues />}{active==='gallery' && <Gallery />}</main>
  </div>
}
