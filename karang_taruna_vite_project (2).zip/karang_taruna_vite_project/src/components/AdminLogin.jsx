import React, { useState } from 'react'
import { idbGet } from '../utils/idb'

export default function AdminLogin({ onSuccess }) {
  const [user, setUser] = useState('admin');
  const [pass, setPass] = useState('');
  const [err, setErr] = useState('');

  const login = async () => {
    const cred = await idbGet('admin_cred');
    if (!cred) { setErr('Credential tidak ditemukan'); return; }
    if (user === cred.username && pass === cred.password) {
      onSuccess();
    } else {
      setErr('Username atau password salah.');
    }
  };

  return <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-neutral-100 to-neutral-200 p-6">
    <div className="w-full max-w-md bg-white rounded-2xl p-6 shadow">
      <h2 className="text-xl font-semibold mb-3">Login Admin</h2>
      <label className="block text-sm mb-2">Username<input className="w-full rounded-xl border px-3 py-2 mt-1" value={user} onChange={e=>setUser(e.target.value)} /></label>
      <label className="block text-sm mb-3">Password<input type="password" className="w-full rounded-xl border px-3 py-2 mt-1" value={pass} onChange={e=>setPass(e.target.value)} /></label>
      {err && <div className="text-sm text-red-600 mb-2">{err}</div>}
      <div className="flex gap-2 justify-end"><button className="px-3 py-2 rounded-xl bg-blue-600 text-white" onClick={login}>Masuk</button></div>
      <div className="text-xs text-neutral-500 mt-3">Default admin: <strong>admin</strong> / <strong>admin123</strong>. Silakan ubah setelah login.</div>
    </div>
  </div>
}
